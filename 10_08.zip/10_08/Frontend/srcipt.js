fetch("http://localhost:3000/games")
.then(response => response.json())
.then((data) => {
    data.map(game => {
        document.getElementById("games").innerHTML += `
        <div class="card" style="width: 18rem;">
            <img src="${game.imageUrl}" class="card-img-top" alt="${game.title}">
            <div class="card-body">
                <h5 class="card-title">${game.title}</h5>
                <p class="card-text">Genre: ${game.genre}</p>
                <p class="card-text">Release year: ${game.releaseYear}</p>
                <a href="#" class="btn btn-primary">Játék</a>
            </div>
        </div>
        `
    });
});

//npm --version
//npm install
//npm start