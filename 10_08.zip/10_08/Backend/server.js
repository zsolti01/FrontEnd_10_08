const express = require("express");
const cors = require("cors");
const swaggerUi = require("swagger-ui-express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3000;
const DB_FILE = path.join(__dirname, "db.json");

app.use(cors());
app.use(express.json());

// Minden szerverindításkor ebből a 10 játékból készül újra a db.json.
const initialGames = [
  {
    id: 1,
    title: "Grand Theft Auto V",
    genre: "Action-adventure",
    releaseYear: 2015,
    imageUrl: "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/271590/header.jpg"
  },
  {
    id: 2,
    title: "Minecraft",
    genre: "Sandbox",
    releaseYear: 2011,
    imageUrl: "https://upload.wikimedia.org/wikipedia/en/b/b6/Minecraft_2024_cover_art.png"
  },
  {
    id: 3,
    title: "Cyberpunk 2077",
    genre: "Action RPG",
    releaseYear: 2020,
    imageUrl: "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/1091500/header.jpg"
  },
  {
    id: 4,
    title: "The Witcher 3: Wild Hunt",
    genre: "Action RPG",
    releaseYear: 2015,
    imageUrl: "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/292030/header.jpg"
  },
  {
    id: 5,
    title: "Red Dead Redemption 2",
    genre: "Action-adventure",
    releaseYear: 2019,
    imageUrl: "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/1174180/header.jpg"
  },
  {
    id: 6,
    title: "Elden Ring",
    genre: "Action RPG",
    releaseYear: 2022,
    imageUrl: "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/1245620/header.jpg"
  },
  {
    id: 7,
    title: "Counter-Strike 2",
    genre: "FPS",
    releaseYear: 2023,
    imageUrl: "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/730/header.jpg"
  },
  {
    id: 8,
    title: "Baldur's Gate 3",
    genre: "RPG",
    releaseYear: 2023,
    imageUrl: "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/1086940/header.jpg"
  },
  {
    id: 9,
    title: "Hogwarts Legacy",
    genre: "Action RPG",
    releaseYear: 2023,
    imageUrl: "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/990080/header.jpg"
  },
  {
    id: 10,
    title: "Forza Horizon 5",
    genre: "Racing",
    releaseYear: 2021,
    imageUrl: "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/1551360/header.jpg"
  }
];

function resetDatabase() {
  fs.writeFileSync(DB_FILE, JSON.stringify(initialGames, null, 2), "utf8");
  console.log("Adatbázis újragenerálva.");
}

function readGames() {
  return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
}

function writeGames(games) {
  fs.writeFileSync(DB_FILE, JSON.stringify(games, null, 2), "utf8");
}

resetDatabase();

const swaggerDocument = {
  openapi: "3.0.0",
  info: {
    title: "PC Games CRUD API",
    version: "1.0.0",
    description: "Egyszerű REST API JavaScript fetch és CRUD műveletek gyakorlásához."
  },
  servers: [{ url: `http://localhost:${PORT}` }],
  components: {
    schemas: {
      Game: {
        type: "object",
        properties: {
          id: { type: "integer", example: 1 },
          title: { type: "string", example: "Grand Theft Auto V" },
          genre: { type: "string", example: "Action-adventure" },
          releaseYear: { type: "integer", example: 2015 },
          imageUrl: {
            type: "string",
            example: "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/271590/header.jpg"
          }
        }
      },
      GameInput: {
        type: "object",
        required: ["title", "genre", "releaseYear", "imageUrl"],
        properties: {
          title: { type: "string", example: "Half-Life 2" },
          genre: { type: "string", example: "FPS" },
          releaseYear: { type: "integer", example: 2004 },
          imageUrl: { type: "string", example: "https://example.com/game.jpg" }
        }
      }
    }
  },
  paths: {
    "/games": {
      get: {
        summary: "Összes játék lekérése",
        responses: {
          "200": {
            description: "A játékok listája",
            content: {
              "application/json": {
                schema: {
                  type: "array",
                  items: { $ref: "#/components/schemas/Game" }
                }
              }
            }
          }
        }
      },
      post: {
        summary: "Új játék hozzáadása",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: { $ref: "#/components/schemas/GameInput" }
            }
          }
        },
        responses: {
          "201": {
            description: "A játék létrejött",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Game" }
              }
            }
          },
          "400": { description: "Hiányos vagy hibás adatok" }
        }
      }
    },
    "/games/{id}": {
      get: {
        summary: "Egy játék lekérése ID alapján",
        parameters: [{
          name: "id",
          in: "path",
          required: true,
          schema: { type: "integer" }
        }],
        responses: {
          "200": {
            description: "A megtalált játék",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Game" }
              }
            }
          },
          "404": { description: "A játék nem található" }
        }
      },
      put: {
        summary: "Játék teljes módosítása ID alapján",
        parameters: [{
          name: "id",
          in: "path",
          required: true,
          schema: { type: "integer" }
        }],
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: { $ref: "#/components/schemas/GameInput" }
            }
          }
        },
        responses: {
          "200": {
            description: "A módosított játék",
            content: {
              "application/json": {
                schema: { $ref: "#/components/schemas/Game" }
              }
            }
          },
          "400": { description: "Hiányos vagy hibás adatok" },
          "404": { description: "A játék nem található" }
        }
      },
      delete: {
        summary: "Játék törlése ID alapján",
        parameters: [{
          name: "id",
          in: "path",
          required: true,
          schema: { type: "integer" }
        }],
        responses: {
          "200": { description: "A játék törölve" },
          "404": { description: "A játék nem található" }
        }
      }
    }
  }
};

app.use("/swagger", swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.get("/", (req, res) => {
  res.json({
    message: "PC Games CRUD API",
    games: `http://localhost:${PORT}/games`,
    swagger: `http://localhost:${PORT}/swagger`
  });
});

// GET - összes játék
app.get("/games", (req, res) => {
  res.json(readGames());
});

// GET - játék ID alapján
app.get("/games/:id", (req, res) => {
  const games = readGames();
  const game = games.find(g => g.id === Number(req.params.id));

  if (!game) {
    return res.status(404).json({ message: "A játék nem található." });
  }

  res.json(game);
});

// POST - új játék
app.post("/games", (req, res) => {
  const { title, genre, releaseYear, imageUrl } = req.body;

  if (!title || !genre || !releaseYear || !imageUrl) {
    return res.status(400).json({
      message: "A title, genre, releaseYear és imageUrl mezők megadása kötelező."
    });
  }

  const games = readGames();
  const newId = games.length > 0 ? Math.max(...games.map(g => g.id)) + 1 : 1;

  const newGame = {
    id: newId,
    title,
    genre,
    releaseYear: Number(releaseYear),
    imageUrl
  };

  games.push(newGame);
  writeGames(games);

  res.status(201).json(newGame);
});

// PUT - játék módosítása
app.put("/games/:id", (req, res) => {
  const id = Number(req.params.id);
  const { title, genre, releaseYear, imageUrl } = req.body;

  if (!title || !genre || !releaseYear || !imageUrl) {
    return res.status(400).json({
      message: "A title, genre, releaseYear és imageUrl mezők megadása kötelező."
    });
  }

  const games = readGames();
  const index = games.findIndex(g => g.id === id);

  if (index === -1) {
    return res.status(404).json({ message: "A játék nem található." });
  }

  games[index] = {
    id,
    title,
    genre,
    releaseYear: Number(releaseYear),
    imageUrl
  };

  writeGames(games);
  res.json(games[index]);
});

// DELETE - játék törlése
app.delete("/games/:id", (req, res) => {
  const id = Number(req.params.id);
  const games = readGames();
  const index = games.findIndex(g => g.id === id);

  if (index === -1) {
    return res.status(404).json({ message: "A játék nem található." });
  }

  const deletedGame = games[index];
  games.splice(index, 1);
  writeGames(games);

  res.json({
    message: "A játék sikeresen törölve.",
    game: deletedGame
  });
});

app.listen(PORT, () => {
  console.log(`Szerver: http://localhost:${PORT}`);
  console.log(`Swagger: http://localhost:${PORT}/swagger`);
});
