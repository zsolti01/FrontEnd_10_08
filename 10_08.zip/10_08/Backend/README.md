# PC Games CRUD API

Egyszerű Node.js + Express REST API JavaScript `fetch()` és CRUD műveletek gyakorlásához.

## Indítás

1. Telepítsd a Node.js-t.
2. Nyiss terminált ebben a mappában.
3. Futtasd:

   npm install

4. Ezután:

   npm start

## Címek

- API: http://localhost:3000/games
- Swagger: http://localhost:3000/swagger

## Végpontok

- GET /games
- GET /games/:id
- POST /games
- PUT /games/:id
- DELETE /games/:id

## Fontos

A `db.json` minden szerverindításkor automatikusan visszaáll az eredeti 10 játékra.
Így a POST, PUT és DELETE műveletekkel nyugodtan lehet gyakorolni.
